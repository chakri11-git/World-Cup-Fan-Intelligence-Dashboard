import React from 'react';
import { motion } from 'framer-motion';

/**
 * Reusable wrapper to animate page entries smoothly (Linear/Apple style)
 */
const PageTransition = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -12 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }} // Custom out-quart ease for premium velocity curves
    >
      {children}
    </motion.div>
  );
};

export default PageTransition;
